
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<title>
Không tìm thấy trang này &#8211; Vĩnh Phúc Web</title>
<link href="" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://go.vinhphucweb.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='css_6-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/lity.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_0-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/bootstrap.min.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_1-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/bootstrap-theme.min.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_2-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/owl.carousel.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_3-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/owl.theme.default.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_5-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/css/animate.min.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_style115-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/style.css?ver=4.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='css_icon-css'  href='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/icon/css/font-awesome.min.css?ver=4.9.5' type='text/css' media='all' />
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='http://go.vinhphucweb.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://go.vinhphucweb.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://go.vinhphucweb.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.5" />
</head>
<body class="error404">
<header>
    <div class="top-header hidden-xs">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 logo">
                    <a href="http://go.vinhphucweb.com"><img src="http://go.vinhphucweb.com/wp-content/uploads/2018/04/logo.png" alt="Cáp treo núi chứa chan"><h1 class="hidden">Cáp treo núi chứa chan</h1></a>
                </div>
                <div class="col-sm-6">
                    <form action="http://go.vinhphucweb.com" class="search-form">
                        <input type="text" name="s" placeholder="Tìm kiếm">
                        <button type="submit" class="submit"></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-md navbar-light bg-light" role="navigation">
    <div class="container">
        <div class="row">
    <!-- Brand and toggle get grouped for better mobile display -->
    <button class="navbar-toggler hidden-lg hidden-sm hidden-md" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        <span class="navbar-toggler-icon"></span>
        <span class="navbar-toggler-icon"></span>
        MENU
    </button>
    <a class="navbar-brand hidden-lg hidden-sm hidden-md" href="http://go.vinhphucweb.com"><img src="http://go.vinhphucweb.com/wp-content/uploads/2018/04/mobile-logo.png"></a>
        <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse"><ul id="menu-menu-chinh" class="nav navbar-nav"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1252" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1252 nav-item"><a title=" Trang chủ" href="http://go.vinhphucweb.com/" class="nav-link"><i class="fa fa-home" aria-hidden="true"></i> Trang chủ</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1253" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1253 nav-item"><a title="Giới thiệu" href="http://go.vinhphucweb.com/gioi-thieu/" class="nav-link">Giới thiệu</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1307" class="menu-item menu-item-type-taxonomy menu-item-object-dichvu_cat menu-item-has-children dropdown menu-item-1307 nav-item"><a title="Dịch vụ" href="http://go.vinhphucweb.com/dichvu_cat/dich-vu-cap-treo/" id="menu-item-dropdown-1307">Dịch vụ</a>
<i data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="fa fa-caret-down dropdown-toggle icon-sub"></i><ul class="dropdown-menu" aria-labelledby="menu-item-dropdown-1307" role="menu">
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1308" class="menu-item menu-item-type-post_type menu-item-object-dich-vu menu-item-1308 nav-item"><a title="Du lịch sinh thái" href="http://go.vinhphucweb.com/dich-vu/du-ngoan-cap-treo-3/" class="dropdown-item">Du lịch sinh thái</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1309" class="menu-item menu-item-type-post_type menu-item-object-dich-vu menu-item-1309 nav-item"><a title="Du lịch tín ngưỡng" href="http://go.vinhphucweb.com/dich-vu/du-ngoan-cap-treo-2/" class="dropdown-item">Du lịch tín ngưỡng</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1310" class="menu-item menu-item-type-post_type menu-item-object-dich-vu menu-item-1310 nav-item"><a title="Du ngoạn cáp treo" href="http://go.vinhphucweb.com/dich-vu/du-ngoan-cap-treo/" class="dropdown-item">Du ngoạn cáp treo</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1255" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1255 nav-item"><a title="Tin tức &amp; sự kiện" href="http://go.vinhphucweb.com/category/tin-tuc-su-kien/" class="nav-link">Tin tức &#038; sự kiện</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1312" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown menu-item-1312 nav-item"><a title="Thư viện" href="#" id="menu-item-dropdown-1312">Thư viện</a>
<i data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="fa fa-caret-down dropdown-toggle icon-sub"></i><ul class="dropdown-menu" aria-labelledby="menu-item-dropdown-1312" role="menu">
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1311" class="menu-item menu-item-type-taxonomy menu-item-object-photo_cat menu-item-1311 nav-item"><a title="Hình ảnh" href="http://go.vinhphucweb.com/photo_cat/thu-vien-thang-1/" class="dropdown-item">Hình ảnh</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1313" class="menu-item menu-item-type-taxonomy menu-item-object-video_cat menu-item-1313 nav-item"><a title="Video" href="http://go.vinhphucweb.com/video_cat/du-lich-thang-11/" class="dropdown-item">Video</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1334" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1334 nav-item"><a title="Ưu đãi" href="#" class="nav-link">Ưu đãi</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1333" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1333 nav-item"><a title="Mua online" href="http://go.vinhphucweb.com/mua-online/" class="nav-link">Mua online</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-1256" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1256 nav-item"><a title="Liên hệ" href="http://go.vinhphucweb.com/lien-he/" class="nav-link">Liên hệ</a></li>
</ul></div>    </div>
    </div>
    </nav>
</header>

<div class="content-page">

<section class="main-contact">
<div class="container">
<div class="page_content_">
<p style="font-size:20px;text-align:center"><span style="font-size:30px;font-weight:bold">lỗi 404</span></br></br>Trang không tồn tại . Quay về <a href="http://go.vinhphucweb.com"> Trang Chủ</a></p>

</div>
</div>
</section>

</div>



<footer class="wow fadeInUp" data-wow-duration="1.8s">
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        	<div id="media_image-2" class="widget widget_media_image"><img width="212" height="90" src="http://go.vinhphucweb.com/wp-content/uploads/2018/04/logofooter.png" class="image wp-image-1290  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" /></div>            
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        	<div id="text-12" class="widget widget_text">			<div class="textwidget"><p>VINHPHUCWEB là nhà phát triển website chuyên nghiệp uy tín tại Vĩnh Phúc. Chúng tôi thiết kế web theo chuẩn SEO, chuẩn di động. Áp dụng những công nghệ tiên tiến nhất hiện nay để thiết kế website như HTML5, CSS3, PHP, các hệ quản trị nội dung WP ,joomla … Giá rẻ và hỗ trợ chọn đời . Nhằm mang lại sự hiệu quả thực sự cho khách hàng</p>
</div>
		</div>        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        	
<div class="img_footer">
<h3>LIÊN KẾT </h3>
</div>
<ul class="social">
<li>
   <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
</li>
<li class="not-before">
    <a href=""><i class="fa fa-google" aria-hidden="true"></i></a>
</li>
<li class="not-before">
    <a href=""><i class="fa fa-pinterest" aria-hidden="true"></i></a>
</li>
<li class="not-before">
    <a href=""><i class="fa fa-youtube" aria-hidden="true"></i></a>
</li>
<li class="not-before">
    <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
</li>
</ul>


            
        </div>
    </div>
</div>
</footer>


<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/vi_VN/all.js#xfbml=1";
fjs.parentNode.insertBefore(js, fjs);
}(document, "script", "facebook-jssdk"));</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/go.vinhphucweb.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"H\u00e3y x\u00e1c nh\u1eadn r\u1eb1ng b\u1ea1n kh\u00f4ng ph\u1ea3i l\u00e0 robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.1'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/js/jquery.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/js/bootstrap.min.js?ver=4.9.5'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/js/owl.carousel.js?ver=4.9.5'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-content/themes/vpw_theme/js/lity.js?ver=4.9.5'></script>
<script type='text/javascript' src='http://go.vinhphucweb.com/wp-includes/js/wp-embed.min.js?ver=4.9.5'></script>

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
</body>
</html>

